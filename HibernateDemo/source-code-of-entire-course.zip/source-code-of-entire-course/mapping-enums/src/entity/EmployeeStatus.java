package entity;

public enum EmployeeStatus {
	FULL_TIME, 
	PART_TIME, 
	CONTRACT
}
