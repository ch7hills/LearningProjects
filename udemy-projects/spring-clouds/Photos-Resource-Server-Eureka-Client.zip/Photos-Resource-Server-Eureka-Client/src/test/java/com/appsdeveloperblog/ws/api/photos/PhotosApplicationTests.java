package com.appsdeveloperblog.ws.api.photos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhotosApplicationTests {

	@Test
	void contextLoads() {
	}

}
